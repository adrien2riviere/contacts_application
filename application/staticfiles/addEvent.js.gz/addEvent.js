var date_text = document.getElementById('date').innerText
date_text = date_text.replaceAll('-', '/')
document.getElementById('date').innerText = date_text